import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ConfigServlet extends HttpServlet {

	private String userEmail;

	@Override
	public void init() throws ServletException {
		// ServletConfig ��ü�� ���Ѵ�.
		ServletConfig config = this.getServletConfig();
		userEmail = config.getInitParameter("userEmail");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		response.setContentType("text/html; charset=utf-8");
		
		//1. ServletContext ������ ���ε��� ������ �̸����� ���Ѵ�.
		String adminEmail = (String)this.getServletContext().getAttribute("adminEmail");
		
		PrintWriter pw = response.getWriter();
		pw.print("adminEmail : " + adminEmail + "<br>");
		pw.print("userEmail : " + userEmail + "<br>");
		pw.close();
		
	}

}








