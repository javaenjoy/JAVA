package model;

import java.sql.Connection;

import domain.BoardFileVo;
import domain.BoardVo;

public class BoardService {
	// single pattern
	private static BoardService service;

	private BoardService() {

	}

	public static BoardService getInstance() {
		if (service == null) {
			service = new BoardService();
		}
		return service;
	}

	// �Խñ� ������ ����ϴ�.
	public void registerBoard(BoardVo board) throws Exception {
		Connection conn = null;
		boolean isSuccess = false;
		try {
			conn = DBConn.getConnection();
			// tx.begin
			conn.setAutoCommit(false);

			// 1.�Խñ� ������ ����Ѵ�.
			BoardDao boardDao = BoardDao.getInstance();
			int no = boardDao.insertBoard(board, conn);

			for (BoardFileVo file : board.getFileList()) {
				file.setBoardNo(no);
			}

			// 2.���� ������ ����ϴ�.
			BoardFileDao fileDao = BoardFileDao.getInstance();

			for (BoardFileVo file : board.getFileList()) {
				fileDao.insertBoardFile(file, conn);
			}
			isSuccess = true;

		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (conn != null) {
					if (isSuccess) {
						conn.commit();
					} else {
						conn.rollback();
					}
					conn.close(); 
				}
			} catch (Exception ex) {
				throw ex;
			}
		}
	}
	
	
	//�Խñ� �������� ��ȸ�ϴ�.
	public BoardVo retrieveBoard(int no) throws Exception {
		BoardDao boardDao = BoardDao.getInstance();
		return boardDao.selectBoard(no);
		
	}
	
}
























