package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteBoardFormCommand implements Command {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		//�Խñ� ���� �� ��û ó�� Ŀ�ǵ�
		ActionForward forward = new ActionForward("/writeBoardForm.jsp", false);
		return forward;
		
	}

}
