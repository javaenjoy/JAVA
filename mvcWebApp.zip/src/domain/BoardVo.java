package domain;

public class BoardVo {
	private int no;
	private String writer;
	private String password;
	private String subject;
	private String content;
	private String writedate;
	private int hitcount;

	public BoardVo() {
		super();
	}
	
	public BoardVo(int no, String writer, String subject, String writedate, int hitcount) {
		super();
		this.no = no;
		this.writer = writer;
		this.subject = subject;
		this.writedate = writedate;
		this.hitcount = hitcount;
	}



	public BoardVo(String writer, String password, String subject, String content) {
		super();
		this.writer = writer;
		this.password = password;
		this.subject = subject;
		this.content = content;
	}


	public BoardVo(int no, String writer, String password, String subject, 
			String content, String writedate, int hitcount) {
		super();
		this.no = no;
		this.writer = writer;
		this.password = password;
		this.subject = subject;
		this.content = content;
		this.writedate = writedate;
		this.hitcount = hitcount;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	public String getWritedate() {
		return writedate;
	}

	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}

	public int getHitcount() {
		return hitcount;
	}

	public void setHitcount(int hitcount) {
		this.hitcount = hitcount;
	}

}
