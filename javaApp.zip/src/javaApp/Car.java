package javaApp;


//자동차를 구현한 클래스

public class Car extends Object {
	//필드
	// 인스턴스 변수
	private String name;
	private String color;
	private int direction;
	private int speed;
	//클래스(static) 변수
	private static String company;
	
	
	//클래스 초기화 블록
	//클래스 변수 초기화
	static {
		//System.out.println("call static initialize block!!");
		company = "현대";
	}
	
	
	// 디폴트 생성자 메소드
	public Car() {
		//super();
	}

	
	//매개변수를 갖는 생성자 메소드
	public Car(String name, String color) {
		//super();
		this.name = name;
		this.color = color;
	}


	//매개변수를 갖는 생성자 메소드
	public Car(String name, String color, int direction, int speed) {	
		this.name = name;
		this.color = color;
		this.direction = direction;
		this.speed = speed;
	}
	
	
	//인스턴스 메소드
	//이름을 구하다
	public String getName() {
		System.out.printf("this = %s%n", this);
		return this.name;	
	}
	
	//이름을 변경하다.
	public void setName(String name) {
		this.name = name;	
	}
	
	//가속하다.
	public void accelerate() {
		this.speed++;    //this.speed += 1    //this.speed =  this.speed + 1
	}
	
	
	//속도를 구하다.
	public int getSpeed() {
		return speed;
	}
	
	
	public void print() {
		System.out.printf("이름 : %s%n", name);
		System.out.printf("색상 : %s%n", color);
		System.out.printf("방향 : %d%n", direction);
		System.out.printf("속도 : %d%n", speed);
		test();
	}
	
	
	//클래스 메소드
	public static String getCompany() {
		return company;
	}
	
	private void test() {
		System.out.println("private access modifier method!!");		
	}


	@Override
	public String toString() {
		return "Car [name=" + name + ", color=" + color + ", direction=" 
					+ direction + ", speed=" + speed + "]";
	}
	
	
	@Override
	public boolean equals(Object obj) {
		Car car = (Car)obj;
		
		if (this.name.equals(car.name) &&
		    this.color.equals(car.color) &&
		    this.direction == car.direction &&
		    this.speed == car.speed) {
			return true;
		} else {
			return false;
		}
		
	}	
	
}























