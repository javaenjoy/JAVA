package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import domain.BoardFileVo;
import domain.BoardVo;

public class BoardDao {
	// singleton pattern
	private static BoardDao boardDao;

	private BoardDao() {

	}

	public static BoardDao getInstance() {
		if (boardDao == null) {
			boardDao = new BoardDao();
		}
		return boardDao;
	}

	// �Խñ� ������ ����ϴ�.
	public int insertBoard(BoardVo board, Connection conn) throws Exception {
		int no = 0;
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {			
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO board (writer, password, subject, content) ");
			sql.append("VALUES (?,  ?,  ?,  ? )");
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.setString(1, board.getWriter());
			pstmt.setString(2, board.getPassword());
			pstmt.setString(3, board.getSubject());
			pstmt.setString(4, board.getContent());

			pstmt.executeUpdate();
			pstmt.close();
			
			//DB�� ����� �Խñ��� �Խñ� ��ȣ�� ���Ѵ�.
			stmt = conn.createStatement();
			
			sql.delete(0, sql.length());
			sql.append("SELECT LAST_INSERT_ID()");			
			rs = stmt.executeQuery(sql.toString());
			
			if(rs.next()) {
				no = rs.getInt(1);
			}			

		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (rs != null) rs.close();
				if (stmt != null) stmt.close();				
			} catch (Exception e2) {
				throw e2;
			}
		}
		return no;
	}

	
	// �Խñ� ����� ��ȸ�ϴ�.
	public ArrayList<BoardVo> selectBoardList() throws Exception {
		ArrayList<BoardVo> boards = new ArrayList<BoardVo>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = DBConn.getConnection();

			stmt = conn.createStatement();

			StringBuffer sql = new StringBuffer();
			sql.append("SELECT no, writer, subject,                                            ");
			sql.append("DATE_FORMAT(writedate, '%Y/%m/%d %H:%i:%s') as writedate, hitcount     ");
			sql.append("FROM board                                                             ");
			sql.append("ORDER BY writedate DESC");

			rs = stmt.executeQuery(sql.toString());

			while (rs.next()) {
				int no = rs.getInt(1);
				String writer = rs.getString(2);
				String subject = rs.getString(3);
				String writedate = rs.getString(4);
				int hitcount = rs.getInt(5);
				boards.add(new BoardVo(no, writer, subject, writedate, hitcount));
			}

		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				throw e2;
			}
		}
		return boards;
	}

	// ��ȸ���� �����ϴ�.
	public void upHitcount(int no) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBConn.getConnection();

			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE board                   ");
			sql.append("SET hitcount = hitcount + 1    ");
			sql.append("WHERE no = ?");
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.setInt(1, no);

			pstmt.executeUpdate();

		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				throw e2;
			}
		}
	}

	// �Խñ� ��ȣ�� �ش��ϴ� �Խñ� �������� ��ȸ�ϴ�.
	public BoardVo selectBoard(int no) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BoardVo board = new BoardVo();	
		try {
			conn = DBConn.getConnection();
			
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT b.no, b.writer, b.password, b.subject, b.content,                "); 
			sql.append("date_format(b.writedate, '%Y/%m/%d %h:%i:%s') as writedate, b.hitcount, ");
			sql.append("f.originalFileName, f.systemFileName, f.fileSize                        ");
			sql.append("FROM board as b LEFT JOIN boardFile as f                                ");
			sql.append("ON b.no = f.boardNo                                                     ");
			sql.append("WHERE b.no = ?");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery();
			
			boolean isFirst = true;
			while (rs.next()) {
				if(isFirst) {
					board.setNo(rs.getInt(1));
					board.setWriter(rs.getString(2));
					board.setPassword(rs.getString(3));
					board.setSubject(rs.getString(4));
					board.setContent(rs.getString(5));
					board.setWritedate(rs.getString(6));
					board.setHitcount(rs.getInt(7));
					isFirst = false;
				}
				if(rs.getString(8) != null) {
					BoardFileVo file = new BoardFileVo();
					file.setOriginalFileName(rs.getString(8));
					file.setSystemFileName(rs.getString(9));
					file.setFileSize(rs.getInt(10));
					board.addBoardFile(file);
				}	
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
			} catch (Exception e2) {
				throw e2;
			}
		}		
		return board;
	}

	//�Խñ� ������ �����ϴ�.
	public void updateBoard(BoardVo board) throws Exception {
	
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBConn.getConnection();
			
			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE board                                 ");
			sql.append("SET writer = ?, subject = ?, content = ?      ");
			sql.append("WHERE no = ?");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setString(1, board.getWriter());
			pstmt.setString(2, board.getSubject());
			pstmt.setString(3, board.getContent());
			pstmt.setInt(4, board.getNo());
			
			pstmt.executeUpdate();			
			
		} catch (Exception e) {
			throw e;
		} finally {
			try {				
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
			} catch (Exception e2) {
				throw e2;
			}
		}		
		
	}
	
}
























