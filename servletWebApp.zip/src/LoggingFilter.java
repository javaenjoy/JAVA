
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

//@WebFilter("/*")
public class LoggingFilter implements Filter {
	private FilterConfig fConfig;
	
	public void init(FilterConfig fConfig) throws ServletException {
		this.fConfig = fConfig;
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
		throws IOException, ServletException {		
		//Ŭ���̾�Ʈ IP Address�� ���Ѵ�.
		String ip = request.getRemoteAddr();
		String uri = ((HttpServletRequest)request).getRequestURI();		
		
		// ServletContext ��ü�� ���Ѵ�.
		ServletContext context = fConfig.getServletContext();
		
		// ����ġ ��Ĺ��  �α������� ����Ѵ�.
		context.log("Client IP Address : " + ip);
		context.log("Client Request URI : " + uri);
		
		chain.doFilter(request, response);
	}
}






