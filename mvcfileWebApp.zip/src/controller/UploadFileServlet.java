package controller;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import domain.BoardFileVo;
import domain.BoardVo;
import model.BoardService;
import util.FileUploadUtils;

@MultipartConfig(fileSizeThreshold = 1024, maxFileSize = -1L, maxRequestSize = -1L, location = "/temp")
@WebServlet("/uploadFile")
public class UploadFileServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		try {
			Collection<Part> parts = request.getParts();
			BoardVo board = new BoardVo();
			for (Part part : parts) {
				//System.out.println(part.getHeaderNames());
				//System.out.println(part.getHeader("content-disposition"));
				
				// form-data
				if (!part.getHeader("content-disposition").contains("filename=")) {
					String name = part.getName();
					System.out.printf("name: %s%n", name);
					if (name.equals("writer")) {						
						board.setWriter(request.getParameter(name));
					} else if (name.equals("subject")) {
						board.setSubject(request.getParameter(name));
					} else if (name.equals("password")) {
						board.setPassword(request.getParameter(name));
					} else if (name.equals("content")) {
						board.setContent(request.getParameter(name));
					}

				} else { // upload file�� ���
					if (part.getSize() != 0) {
						BoardFileVo file = FileUploadUtils.upload(part);
						board.addBoardFile(file);
					}
				}
			}

			BoardService service = BoardService.getInstance();
			service.registerBoard(board);
			
			response.sendRedirect(request.getContextPath() + "/listBoard.do");
			

		} catch (Exception ex) {
			request.setAttribute("exception", ex);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/error.jsp");
			dispatcher.forward(request, response);			
		}

	}

}












