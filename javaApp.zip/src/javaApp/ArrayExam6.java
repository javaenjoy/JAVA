package javaApp;

public class ArrayExam6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] arr = new int[4][];
		
		System.out.printf("arr = %s%n", arr);
		System.out.printf("arr �迭�� ���� = %d%n", arr.length);
		
		
		for (int i = 0; i < arr.length; i++) {
			System.out.printf("arr[%d] = %s%n", i, arr[i]);
		}
		
		
		arr[0] = new int[1];
		System.out.printf("arr[0] = %s%n", arr[0]);
		System.out.printf("arr[0] �迭�� ���� = %d%n", arr[0].length);
		
		arr[1] = new int[2];
		System.out.printf("arr[1] = %s%n", arr[1]);
		System.out.printf("arr[1] �迭�� ���� = %d%n", arr[1].length);
		
		arr[2] = new int[3];
		System.out.printf("arr[2] = %s%n", arr[1]);
		System.out.printf("arr[2] �迭�� ���� = %d%n", arr[2].length);
		
		arr[3] = new int[4];
		System.out.printf("arr[3] = %s%n", arr[1]);
		System.out.printf("arr[3] �迭�� ���� = %d%n", arr[3].length);	
		
	}

}
