
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value = "/lifeCycle" , 
		    initParams = {@WebInitParam(name = "userEmail", value = "servlet@gmail.com")})
public class LifeCycleServlet extends HttpServlet {
	
	String userEmail;
	String adminEmail;
	
	
	public LifeCycleServlet() {
		System.out.println("call Default Constructor");
	}
	
	@Override
	public void init() throws ServletException {	
		System.out.println("call init()");
		
		adminEmail = this.getServletContext().getInitParameter("adminEmail");
		userEmail = this.getServletConfig().getInitParameter("userEmail");	
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		System.out.println("call doGet()");
		
		response.setContentType("text/html; charset=utf-8");
		
		PrintWriter pw = response.getWriter();
		pw.println("<html><body>");
		pw.println("<h2>LifeCycleServlet!!</h2>");
		pw.println("<h2>������ �̸��� : " + adminEmail + "</h2>");
		pw.println("<h2>����� �̸��� : " + userEmail + "</h2>");		
		pw.println("</body></html>");
		pw.close();
		
	}	

	@Override
	public void destroy() {
		System.out.println("call destroy()");
	}


}







