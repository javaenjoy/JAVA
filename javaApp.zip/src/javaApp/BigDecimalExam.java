package javaApp;

import java.math.BigDecimal;

public class BigDecimalExam {

	public static void main(String[] args) {
		
		double salary = 80000000;
		System.out.print(salary);
		
		BigDecimal obj = new BigDecimal(salary);
		System.out.println(obj.toString());
		System.out.printf("%,.2f", Double.parseDouble(obj.toString()));
	}

}
