package controller;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

public class CommandFactory {
	//�̱��� ����
	private static CommandFactory factory;
	private Map<String, String> map = new HashMap<String, String>();
	
	private CommandFactory() {
		//�Խñ� ���� �� ��û
		map.put("/writeBoardForm.do", "controller.WriteBoardFormCommand");
		//�Խñ�  ��Ϻ��� ��û
		map.put("/listBoard.do", "controller.ListBoardCommand");
		//�Խñ�  ����ȸ ��û
		map.put("/detailBoard.do", "controller.DetailBoardCommand");
							
	}
	
	
	public static CommandFactory getInstance() {
		if(factory == null) {
			factory = new CommandFactory();
		}
		return factory;
	}
	
	
	public Command createCommand(String commandURI) throws Exception {
		String commandClass = map.get(commandURI);
		if (commandClass == null) {
			return null;
		}
		
		try {	
			// ���� Ŭ���� �ε� �� �ν��Ͻ� ����  
			Class<?> cls = Class.forName(commandClass);
			Constructor<?> constructor = cls.getConstructor(null);
			Command command = (Command)constructor.newInstance();
			return command;
		} catch (Exception e) {
			throw e;
		}
		
	}	
}









