package util;

import java.io.File;
import java.util.UUID;

import javax.servlet.http.Part;
import domain.BoardFileVo;

public class FileUploadUtils {
	
	public static final String UPLOAD_PATH = "C:/upload";
	
	public static BoardFileVo upload(Part part) throws Exception {
		
		String originalFileName = part.getSubmittedFileName();
		
		File file = new File(UPLOAD_PATH + "/" + originalFileName);
		String systemFileName = "";
		if (file.exists()) {
			systemFileName = originalFileName.substring(0, originalFileName.lastIndexOf(".")) + "_" +
				UUID.randomUUID() + originalFileName.substring(originalFileName.lastIndexOf("."));
			
		} else {
			systemFileName = originalFileName;
		}
		
		int fileSize = (int)part.getSize();
		
		part.write(UPLOAD_PATH + "/" + systemFileName);
		part.delete();
		
		BoardFileVo boardFile = new BoardFileVo(originalFileName, systemFileName, fileSize);
		return boardFile;
		
	}
	

}




















