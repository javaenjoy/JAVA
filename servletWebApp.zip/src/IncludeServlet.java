import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/include")
public class IncludeServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. ����Ʈ Ÿ���� �����Ѵ�.
		response.setContentType("text/html; charset=utf-8");

		// 2.
		PrintWriter pw = response.getWriter();
		pw.print("<h1>call Before NextIncludeServlet</h1>");

		RequestDispatcher dispatcher = request.getRequestDispatcher("/nextInclude");
		dispatcher.include(request, response);

		pw.print("<h1>call After NextIncludeServlet</h1>");
		pw.close();
	}

}







