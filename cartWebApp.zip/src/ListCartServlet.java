
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/listCart")
public class ListCartServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		// HttpSession ���� ��ü�� ���Ѵ�.
		HttpSession session = request.getSession();
		
		// HttpSession ���� ��ü��  "cart"��� �Ӽ��̸����� ���ε��� ��ٱ��ϸ� ���Ѵ�.
		Cart cart = (Cart)session.getAttribute("cart");
		
		if (cart == null) {
			response.sendRedirect(request.getContextPath() + "/viewItem.html");
		} else {
			ArrayList<Item> itemList = cart.retrieveCartList();
			
			response.setContentType("text/html; charset=utf-8");
			PrintWriter pw = response.getWriter();
			pw.print("<html><body>");
			pw.print("<table border='1'>");
			pw.print("<tr><th>��ǰ��ȣ</th><th>��ǰ��</th><th>����</th><th>����</th><th>���</th></tr>");
		
			if (itemList.isEmpty()) {
				pw.print("<tr><td colspan='5'>��ٱ��Ͽ� �߰��� ��ǰ�� �����ϴ�.</td></tr>");
			} else {
				for (Item item : itemList) {
					pw.print("<form action='/cartWebApp/modifyCart' method ='GET'>");
					pw.print("<input type='hidden' name='no' value=" + item.getNo() + ">");
					pw.print("<tr>");
					pw.print("<td>" + item.getNo() + "</td>");
					pw.print("<td>" + item.getTitle() + "</td>");
					pw.print("<td>" + item.getPrice() + "</td>");
					pw.print("<td><input type='text' size='1' name='quantity' value=" + item.getQuantity() + ">��</td>");
					pw.print("<td><button type='submit'>����</button>");
					pw.print("<a href='/cartWebApp/removeCart?no=" + item.getNo() + "'>����</a></td>");				
					pw.print("</tr>");
					pw.print("</form>");					
				}
			}			
			pw.print("</table>");
			pw.print("<a href='/cartWebApp/viewItem.html'>��ǰ��ȸ</a><br>");
			pw.print("<a href='/cartWebApp/emptyCart'>��ٱ��� ����</a>");
			pw.print("</body></html>");
			pw.close();
		}
		
	}

}























