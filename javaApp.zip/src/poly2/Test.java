package poly2;

enum Rainbow { RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET }



public class Test {

    public static void main(String[] args) {

        Rainbow rb = Rainbow.valueOf("GREEN");

        System.out.println(rb);

    }

}
