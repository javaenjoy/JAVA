package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import domain.BoardFileVo;


public class BoardFileDao {
	//sigleton pattern
	private static BoardFileDao fileDao;
	
	private BoardFileDao() {
		
	}
	
	public static BoardFileDao getInstance() {
		if (fileDao == null) {
			fileDao = new BoardFileDao();			
		}
		return fileDao;		
	}
	
	
	//������ ����ϴ�.
	public void insertBoardFile(BoardFileVo file, Connection conn) throws Exception {
		PreparedStatement pstmt = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO boardFile (originalFileName, systemFileName, fileSize, boardNo)  ");
			sql.append("VALUES (?, ?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setString(1, file.getOriginalFileName());
			pstmt.setString(2, file.getSystemFileName());
			pstmt.setInt(3, file.getFileSize());
			pstmt.setInt(4, file.getBoardNo());
			
			pstmt.executeUpdate();			
			
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) pstmt.close();
			} catch (Exception e2) {
				throw e2;
			}
		}		
	}
	
	//������ �����Ѵ�.
	public void deleteFile(int boardNo, Connection conn) throws Exception {
		PreparedStatement pstmt = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("DELETE FROM boardFile       ");
			sql.append("WHERE boardNo = ?");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setInt(1, boardNo);			
			
			pstmt.executeUpdate();			
			
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) pstmt.close();
			} catch (Exception e2) {
				throw e2;
			}
		}		
	}

}
























