
public class Item {
	private int no;
	private String title;
	private int price;
	private int quantity;
	
	
	public Item() {
		super();
	}


	public Item(int no, String title, int price, int quantity) {
		super();
		this.no = no;
		this.title = title;
		this.price = price;
		this.quantity = quantity;
	}


	public int getNo() {
		return no;
	}


	public void setNo(int no) {
		this.no = no;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	

}
