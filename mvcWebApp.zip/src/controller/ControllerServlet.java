package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.do")
public class ControllerServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		processRequest(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		processRequest(request, response);
	}

	public void processRequest(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		try {
			String requestURI = request.getRequestURI();
			String contextPath = request.getContextPath();
			String commandURI = requestURI.substring(contextPath.length());

			System.out.printf("requestURI : %s%n", requestURI);
			System.out.printf("contextPath : %s%n", contextPath);
			System.out.printf("commandURI : %s%n", commandURI);

			CommandFactory factory = CommandFactory.getInstance();
			Command command = factory.createCommand(commandURI);
			ActionForward forward = command.execute(request, response);
			
			if (forward.isRedirect()) {  
				//redirect ���
				response.sendRedirect(request.getContextPath() + forward.getPath());
			} else {          
		        //forward ���
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);
			}
			
		} catch (Exception ex) {
			request.setAttribute("exception", ex);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/error.jsp");
			dispatcher.forward(request, response);		
		}
	}
}
















