package javaApp;

public class ArrayExam2 {

	public static void main(String[] args) {
		
		//�迭 ���� �� �ʱ�ȭ
		int[] arr = {1, 4, 6, 2, 7};
		
		for (int i = 0; i < arr.length; i++) {
			System.out.printf("%d\t", arr[i]);
		}
				

	}

}
