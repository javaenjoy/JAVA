package controller;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.BoardVo;
import model.BoardDao;

public class ListBoardCommand implements Command {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		//�Խñ� ��� ��ȸ ��û ó��
		BoardDao boardDao = BoardDao.getInstance();		
		ArrayList<BoardVo> boards = boardDao.selectBoardList();
		
		req.setAttribute("boards", boards);
		return new ActionForward("/listBoard.jsp", false);
	
	}

}




















