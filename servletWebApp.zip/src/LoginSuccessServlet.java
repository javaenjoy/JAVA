
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginSuccess")
public class LoginSuccessServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		//1. request ����� ���Ե� ��Ű ������ ���Ѵ�.
		Cookie[] cookies = request.getCookies();
		String userId = null;
		if(cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("userId")) {
					userId = cookie.getValue();
					break;
				}
			}			
		}
		
		if (userId == null || cookies == null) {
			response.sendRedirect(request.getContextPath() + "/loginForm.html");
		} else {			
			response.setContentType("text/html; charset=utf-8");
			
			PrintWriter pw = response.getWriter();
			pw.println("<h1>" + userId + "���� �α����ϼ̽��ϴ�.<h1>");
			pw.println("<h1><a href='/servletWebApp/logout'>�α׾ƿ�</a><h1>");
			pw.close();
		}		
		
	}

}









































