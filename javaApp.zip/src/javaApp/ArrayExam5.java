package javaApp;

public class ArrayExam5 {

	public static void main(String[] args) {
		
		//�迭 ���� �� �ʱ�ȭ
		int[][] arr = {{1, 2, 3, 4, 5},
				       {6, 7, 8, 9, 10}}; 
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.printf("arr[%d][%d] = %d%n", i, j, arr[i][j]);
			}
		}
	}

}
