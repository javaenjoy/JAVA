
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/logoutHandler")
public class LogoutHandlerServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. HttpSession ��ü�� ���ϴ�.
		HttpSession session = request.getSession();
		
		// 2. HttpSession ���� ��ü�� ���ε���  ���̵� ���Ѵ�.
		String userId = (String)session.getAttribute("userId");
		
		if (userId != null) {
			session.invalidate();
			response.setContentType("text/html; charset=utf-8");
			PrintWriter pw = response.getWriter();
			pw.print("<h1>" + userId + "���� �α׾ƿ��ϼ̽��ϴ�.</h1>");
			pw.close();
			
		} else {
			response.sendRedirect(request.getContextPath() + "/loginForm.html");
		}

	}

}
























