package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.BoardVo;
import model.BoardService;

public class DetailBoardCommand implements Command {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		//1. �Խñ� ��ȣ�� ���Ѵ�.
		int no = Integer.parseInt(req.getParameter("no"));
		
		BoardService service = BoardService.getInstance();
		BoardVo board = service.retrieveBoard(no);
		
		req.setAttribute("board", board);
		
		return new ActionForward("/detailBoard.jsp", false);
		
	}
	

}
