import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// http://localhost:8080/servletWebApp/image

@WebServlet("/image")
public class ImageServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		//1. ����Ʈ Ÿ���� �����Ѵ�.
		response.setContentType("image/jpeg");
		
		BufferedInputStream bis = null;
		ServletOutputStream sos = null;
		try {
			bis = new BufferedInputStream(new FileInputStream("C:/io/earth.jpg"));
			sos = response.getOutputStream();
		
			byte[] buf = new byte[1024];
			int readByte = 0;
			while((readByte = bis.read(buf)) != -1) {
				sos.write(buf, 0, readByte);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bis != null) bis.close();
				if (sos != null) sos.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

}








