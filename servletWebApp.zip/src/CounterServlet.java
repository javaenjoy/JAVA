
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/counter")
public class CounterServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		//1. ��Ű�� ���Ѵ�.
		Cookie[] cookies = request.getCookies();

		Cookie cookie = null;
		int count = 0;
		if (cookies != null) {
			for (Cookie temp : cookies) {
				if (temp.getName().equals("count")) {
					cookie = temp;
					count = Integer.parseInt(temp.getValue());
				}
			}			
		}		
		
		if(cookie == null || cookies == null) {			
			  count = 1; 
			  cookie = new Cookie("count", String.valueOf(count)); 
			 
		} else {
			  cookie.setValue(String.valueOf(++count));
		}
		
		cookie.setMaxAge(60*60*24); //1��
		response.addCookie(cookie);
		
		response.setContentType("text/html; charset=utf-8");
		PrintWriter pw = response.getWriter();
		pw.print("<h1>" + count + "��° �湮�ϼ̽��ϴ�.</hl>");
		pw.close();

	}

}















