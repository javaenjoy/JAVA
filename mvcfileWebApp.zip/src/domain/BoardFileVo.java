package domain;

public class BoardFileVo {
	private int no;
	private String originalFileName;
	private String systemFileName;
	private int fileSize;
	private int boardNo;
	
	public BoardFileVo() {
		super();
	}

	public BoardFileVo(String originalFileName, String systemFileName, int fileSize) {
		this.originalFileName = originalFileName;
		this.systemFileName = systemFileName;
		this.fileSize = fileSize;
	}
	
	
	public BoardFileVo(int no, String originalFileName, String systemFileName, 
		int fileSize, int boardNo) {
		super();
		this.no = no;
		this.originalFileName = originalFileName;
		this.systemFileName = systemFileName;
		this.fileSize = fileSize;
		this.boardNo = boardNo;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public String getSystemFileName() {
		return systemFileName;
	}

	public void setSystemFileName(String systemFileName) {
		this.systemFileName = systemFileName;
	}

	public int getFileSize() {
		return fileSize;
	}

	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

	public int getBoardNo() {
		return boardNo;
	}

	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}

}
