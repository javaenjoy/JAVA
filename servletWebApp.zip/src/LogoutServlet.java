
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		
		// 1. ��Ű������ ���Ѵ�.
		Cookie[] cookies = request.getCookies();
		
		String userId = null;
		Cookie cookie = null;
		if(cookies != null) {
			for (Cookie temp : cookies) {
				if (temp.getName().equals("userId")) {
					userId = temp.getValue();
					cookie = temp;
					break;
				}
			}			
		}
		
		
		if (cookies == null || userId == null) {
			response.sendRedirect(request.getContextPath() + "/loginForm.html");
		} else {
			//�α׾ƿ� ��û ó��
			//��Ű������ �����ϴ�.
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			
			response.setContentType("text/html; charset=utf-8");
			PrintWriter pw = response.getWriter();
			pw.print("<h1>" + userId + "���� �α׾ƿ��ϼ̽��ϴ�.</h1>");
			pw.close();			
		}		
	}		

}













