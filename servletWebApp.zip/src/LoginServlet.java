
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		//1. ���̵�� ��й�ȣ�� ���Ѵ�.
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		
		boolean isMember = true;
		if(isMember) {
			//��Ű�� �����Ѵ�.
			Cookie cookie = new Cookie("userId", id);
			cookie.setMaxAge(60*60*24);  //1��
			response.addCookie(cookie);
			
			response.sendRedirect(request.getContextPath() + "/loginSuccess");
			
			
		} else {
			response.sendRedirect(request.getContextPath() + "/loginForm.html");
		}				
	}

}







