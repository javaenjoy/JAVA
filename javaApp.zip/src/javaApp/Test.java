package javaApp;

import java.math.BigDecimal;

public class Test {

	public static void main(String[] args) {
		
		int num = 80000000;
		double result =  (num / 12) * 300/100;
		System.out.println(result);
		
		BigDecimal obj = new BigDecimal(result);
		System.out.printf("%,d", Integer.parseInt(obj.toString()));
	}
}
