
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginSuccessHandler")
public class LoginSuccessHandlerServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		//1. HttpSession ��ü�� ���Ѵ�.
		HttpSession session = request.getSession();
		System.out.printf("JSESSIONID : %s%n", session.getId());
		
		//2. HttpSession ���� ��ü�� ���ε��� �α����� ����� ���̵� ���Ѵ�.
		String userId = (String)session.getAttribute("userId");
		
		if (userId == null) {
			response.sendRedirect(request.getContextPath() + "/loginForm.html");
		} else {
			response.setContentType("text/html; charset=utf-8");
			
			PrintWriter pw = response.getWriter();
			pw.print("<h1>" + userId + "���� �α��� �ϼ̽��ϴ�.</h1>");
			pw.print("<h1><a href='/servletWebApp/logoutHandler'>�α׾ƿ�</a></h1>");
			pw.close();
		}	
		
	}

}























