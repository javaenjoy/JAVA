package javaApp;

public class ArrayExam3 {

	public static void main(String[] args) {
		
		// "�ϱ浿", "�̱浿", "��浿", "ȫ�浿"
		
		String[] arr = { "�ϱ浿", "�̱浿", "��浿", "ȫ�浿" };
		
		for (int i = 0; i < arr.length; i++) {
			System.out.printf("%s\t", arr[i]);
		}
		
		
	}

}
